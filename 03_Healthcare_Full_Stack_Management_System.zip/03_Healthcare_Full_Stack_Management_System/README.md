# Healthcare Patient Support & Appointment Management System

Full-stack portfolio starter demonstrating a healthcare-style enterprise application.

## Architecture
Frontend: React + Vite
Backend: Java Spring Boot
Database: MySQL
Authentication: JWT
Containerization: Docker

## Planned modules
- Patient registration/login
- Appointment booking and history
- Staff dashboard
- Request/status management
- Admin user management
- REST APIs
- Validation and error handling

This repository contains a runnable backend foundation and a frontend starter so the project can be expanded feature-by-feature.
