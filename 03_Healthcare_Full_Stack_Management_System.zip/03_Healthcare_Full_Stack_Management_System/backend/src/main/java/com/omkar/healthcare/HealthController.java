package com.omkar.healthcare;
import org.springframework.web.bind.annotation.*;
import java.util.Map;
@RestController
@RequestMapping("/api")
public class HealthController {
 @GetMapping("/health") public Map<String,String> health(){ return Map.of("status","UP","service","healthcare-api"); }
 @GetMapping("/appointments") public Map<String,Object> appointments(){ return Map.of("message","Appointment module ready","items",new Object[]{}); }
}
